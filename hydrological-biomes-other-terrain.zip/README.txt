Hydrological Biomes, Other Terrain
==================================

WHAT IT DOES
  Keeps Hydrological's 53-entry biome placement list and all 41 of its biome
  definitions (blocks, trees, grass colours, mobs, features), and points world
  generation at "minecraft:overworld" terrain instead of "hydrol:overworld".

  That one change is the whole datapack. Diff against Hydrological's own file:

      - "settings": "hydrol:overworld"
      + "settings": "minecraft:overworld"

WHY THAT HELPS
  "minecraft:overworld" means "whatever terrain is installed". With no terrain
  mod you get vanilla shape at vanilla speed. Install Tectonic, William Wythers'
  Overhauled Overworld, or any mod that overrides the overworld noise settings,
  and Hydrological's biomes ride on top of that terrain instead.

  Hydrological's slow density functions are never evaluated.

INSTALL
  NEW WORLD ONLY. This changes terrain completely; do not add it to a save you
  care about.

  Singleplayer:  Create New World -> Data Packs -> drag this zip in -> Create
  Existing/server: drop the zip in <world>/datapacks/ before first generation

  Hydrological must still be installed -- its biome definitions and custom
  feature types come from the mod.

KNOWN LIMITATION
  Surface rules live inside the noise settings in 1.18+, so switching away from
  "hydrol:overworld" also drops Hydrological's custom surface rules. Biome
  features, trees, foliage colours, mobs and ores are unaffected, but the top
  few blocks of ground use vanilla surface composition.

  If that turns out to matter, tell me and I'll build a version that carries
  Hydrological's surface rules across.

TO REVERT
  Delete the zip from the world's datapacks folder. Only affects new chunks.
